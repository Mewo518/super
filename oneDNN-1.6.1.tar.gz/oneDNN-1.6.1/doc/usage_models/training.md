Training {#dev_guide_training}
==============================

NEW_CONTENT_GOES_HERE

## fp32 Training

NEW_CONTENT_GOES_HERE

## bfp16 Training

NEW_CONTENT_GOES_HERE
